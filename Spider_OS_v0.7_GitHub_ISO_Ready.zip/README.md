# Spider OS

**YOUR LIFE. ONE WEB.**

Spider OS is a personal, local-first Linux operating system. **The Web** is its desktop and **Webbie** is its always-active resident AI connecting the different parts of one life without flattening them into
one giant, badly labeled folder.

Version 0.7 turns Webbie into a resident proactive intelligence:

- A private local database for spaces, tasks, notes, projects, and check-ins
- A local AI connection through Ollama
- A guarded action broker that requires approval for AI-proposed changes
- A Personal Knowledge Web that keeps facts, observations, inferences, and corrections distinguishable
- An autonomous Research Web with self-generated questions, source provenance, confidence, and findings
- Proactive deadline/overdue scanning and a "Webbie Found Something" feed
- Ephemeral local screen context with sensitive-window exclusion and no default pixel archive
- A responsive desktop command center with the Web Assembly startup sequence
- Four coordinated wallpaper families and the Spider OS dark-industrial sound theme
- Universal Blue/Aurora KDE image and distribution scaffolding
- Separate spaces for personal life, recovery, school, current behavioral-health
  work, the future social-work path, art, tattooing, music projects, coding,
  an isolated Kali security lab, finances, relationships, and home

Broken Sorrow is a project inside the Music space. It is not the identity of
the operating system.

## Run the development build

From this directory:

    PYTHONPATH=src python3 -m spider_os serve --open

Then open http://127.0.0.1:8765 if the browser does not open automatically.

The dashboard works without an AI model. For local AI, install Ollama, install
at least one chat-capable model, and start Ollama. Spider OS discovers the first
installed model automatically, or uses the model named by SPIDER_OS_MODEL.

## Commands

    PYTHONPATH=src python3 -m spider_os init
    PYTHONPATH=src python3 -m spider_os doctor
    PYTHONPATH=src python3 -m spider_os serve
    PYTHONPATH=src python3 -m unittest discover -s tests -v

## Data

Personal data is stored under the XDG data directory, normally:

    ~/.local/share/spider-os/spider.db

Set SPIDER_OS_DATA_DIR to use a different location. The data directory is
created with owner-only permissions. Full-disk encryption remains strongly
recommended because application permissions are not a substitute for an
encrypted drive.

## AI authority

Direct clicks and form submissions are treated as user actions. Webbie may run
read-only actions and routine, reversible local organization/research automatically.
Sensitive or consequential actions become proposals and require the appropriate
approval. Arbitrary shell execution is not available to the model.

The behavioral-health workspace is administrative and educational support. It
does not automate diagnosis, observation level, suicide or violence risk
disposition, medication, or emergency decisions.

See docs/ARCHITECTURE.md, docs/SAFETY.md, docs/DECISIONS.md, docs/BRAND.md,
and docs/ROADMAP.md.

## Webbie continuous learning

Webbie is designed to stay resident and keep learning through three reviewable streams:

- **Cory** — explicit preferences, corrections, routines, accepted/rejected suggestions, and project context.
- **Study** — course notes, documents, research, assignments, and other materials Cory chooses to bring into Spider OS.
- **Internet** — broad ongoing research with source provenance, timestamps, confidence, and source-quality weighting.

This is persistent knowledge/memory, not uncontrolled self-training of the base model. Webbie can search what she has learned later. Explicit corrections from Cory outrank inferred patterns.

The Personal Knowledge Web labels each personal memory as a confirmed fact,
observation, inference, or correction. Inferences require evidence links and
remain visibly different from confirmed facts.

## Autonomous Research Web

Webbie may notice knowledge gaps, create her own research questions, and work
through them during idle time. Spider OS stores each question, source, confidence
score, and finding. The default search backend is a local SearXNG instance. Web
research is autonomous; installing software, executing downloaded code, sending,
publishing, purchases, account changes, and other consequential actions are not.

## Graduated authority

Web does not treat every action the same. Read-only observation runs directly; routine local reversible actions can run automatically; sensitive actions require confirmation; destructive, financial, credential, security-critical, legal, or irreversible actions require explicit approval at execution time.

## Web Seed preload

Spider OS ships a versioned, provenance-tagged personal knowledge seed for Webbie. On first database initialization, durable user preferences, Spider OS decisions, education/workflow context, and established creative-project canon are loaded into Webbie's reviewable knowledge layer. The seed is idempotent and versioned so upgrades can add knowledge without duplicating earlier entries. Sensitive credentials and secrets are intentionally excluded.
